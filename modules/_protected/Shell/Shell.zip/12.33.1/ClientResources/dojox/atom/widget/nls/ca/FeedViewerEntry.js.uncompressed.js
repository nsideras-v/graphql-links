define(
"dojox/atom/widget/nls/ca/FeedViewerEntry", ({
	deleteButton: "[Suprimeix]"
})
);
