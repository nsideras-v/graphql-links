//>>built
define("epi/main",["dojo","epi/i18n!epi/shell/ui/nls/episerver.shared"],function(_1,_2){var _3=_1.getObject("epi",true);_3.resources=_1.mixin({},_2);return _3;});