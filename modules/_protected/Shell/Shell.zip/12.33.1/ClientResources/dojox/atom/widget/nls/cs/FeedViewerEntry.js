//>>built
define("dojox/atom/widget/nls/cs/FeedViewerEntry",({deleteButton:"[Odstranit]"}));