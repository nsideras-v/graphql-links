define(
"dojox/atom/widget/nls/az/FeedEntryViewer", ({
	"close" : "[çıx]",
	"title" : "Başlıq",
	"authors" : "Yazıçılar",
	"summary" : "Məzmun",
	"content" : "Tərkib",
	"contributors" : "Əməyi keçənlər",
	"updated" : "Yeniləndi",
	"displayOptions" : "[göstərmə seçimləri]",
	"id" : "Şəxsiyyət"
})
);
