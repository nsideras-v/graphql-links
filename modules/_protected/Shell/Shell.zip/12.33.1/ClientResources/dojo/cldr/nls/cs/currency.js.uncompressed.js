define(
"dojo/cldr/nls/cs/currency", //begin v1.x content
{
	"HKD_displayName": "hongkongský dolar",
	"CHF_displayName": "švýcarský frank",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "kanadský dolar",
	"HKD_symbol": "HK$",
	"CNY_displayName": "čínský jüan",
	"USD_symbol": "US$",
	"AUD_displayName": "australský dolar",
	"JPY_displayName": "japonský jen",
	"CAD_symbol": "CA$",
	"USD_displayName": "americký dolar",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "britská libra",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "euro"
}
//end v1.x content
);