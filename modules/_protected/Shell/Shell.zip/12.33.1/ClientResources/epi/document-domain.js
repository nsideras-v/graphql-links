//>>built
define("epi/document-domain",[],function(){return function(_1){document.domain=_1||document.domain.substring(document.domain.indexOf(".")+1);};});