define(
"dojox/atom/widget/nls/cs/FeedEntryViewer", ({
	displayOptions: "[volby zobrazení]",
	title: "Název",
	authors: "Autoři",
	contributors: "Přispěvatelé",
	id: "ID",
	close: "[zavřít]",
	updated: "Aktualizováno",
	summary: "Souhrn",
	content: "Obsah"
})
);
