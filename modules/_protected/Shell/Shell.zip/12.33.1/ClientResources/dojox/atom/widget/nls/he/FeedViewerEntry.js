//>>built
define("dojox/atom/widget/nls/he/FeedViewerEntry",({deleteButton:"[מחיקה]"}));